package ru.alina.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AssistantAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AssistantAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun goHome() { performGlobalAction(GLOBAL_ACTION_HOME) }
    fun goBack() { performGlobalAction(GLOBAL_ACTION_BACK) }

    fun scrollDown() = swipe(0.5f, 0.78f, 0.5f, 0.28f)
    fun scrollUp() = swipe(0.5f, 0.28f, 0.5f, 0.78f)

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val metrics = resources.displayMetrics
        val path = Path().apply {
            moveTo(metrics.widthPixels * x1, metrics.heightPixels * y1)
            lineTo(metrics.widthPixels * x2, metrics.heightPixels * y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 450))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun clickText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(target)
        val node = nodes.firstOrNull { it.isVisibleToUser && it.isEnabled }
        val result = node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
        nodes.forEach { it.recycle() }
        root.recycle()
        return result
    }

    fun typeIntoFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val ok = focused?.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
        ) == true
        focused?.recycle()
        root.recycle()
        return ok
    }

    fun readVisibleText(): String {
        val root = rootInActiveWindow ?: return ""
        val output = mutableListOf<String>()
        collectText(root, output)
        root.recycle()
        return output.distinct().joinToString(". ")
    }

    private fun collectText(node: AccessibilityNodeInfo, output: MutableList<String>) {
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(output::add)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let {
                collectText(it, output)
                it.recycle()
            }
        }
    }

    fun openApp(query: String): Boolean {
        val pm = packageManager
        val matches = pm.getInstalledApplications(0).filter {
            pm.getApplicationLabel(it).toString().contains(query, ignoreCase = true)
        }
        val app = matches.firstOrNull() ?: return false
        val launch = pm.getLaunchIntentForPackage(app.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }
}
