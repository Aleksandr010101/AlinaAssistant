package ru.alina.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "АЛИНА"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Голосовой помощник готов"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val talk = Button(this).apply {
            text = "Сказать команду"
            setOnClickListener { startListening() }
        }
        val accessibility = Button(this).apply {
            text = "Включить управление экраном"
            setOnClickListener {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val help = TextView(this).apply {
            text = "Примеры: «домой», «назад», «прокрути вниз», «открой YouTube», «нажми Настройки»."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(talk)
        layout.addView(accessibility)
        layout.addView(help)
        setContentView(layout)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("На этом устройстве недоступно распознавание речи.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Я слушаю")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        status.text = "Слушаю…"
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Обрабатываю…" }
            override fun onError(error: Int) {
                status.text = "Не удалось распознать. Попробуй ещё раз."
            }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                status.text = "Ты сказала: $phrase"
                handleCommand(phrase)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale("ru", "RU")).trim()
        val service = AssistantAccessibilityService.instance
        when {
            command in listOf("домой", "на главный экран", "главный экран") -> {
                service?.goHome(); say("Открываю главный экран")
            }
            command in listOf("назад", "вернись назад") -> {
                service?.goBack(); say("Назад")
            }
            command.contains("прокрути вниз") || command == "вниз" -> {
                service?.scrollDown(); say("Прокручиваю вниз")
            }
            command.contains("прокрути вверх") || command == "вверх" -> {
                service?.scrollUp(); say("Прокручиваю вверх")
            }
            command.startsWith("нажми ") -> {
                val target = raw.substringAfter("нажми ", "").trim()
                val ok = service?.clickText(target) == true
                say(if (ok) "Нажимаю $target" else "Не нашла на экране $target")
            }
            command.startsWith("открой ") -> {
                val app = raw.substringAfter("открой ", "").trim()
                val ok = service?.openApp(app) == true
                say(if (ok) "Открываю $app" else "Не смогла найти приложение $app")
            }
            command.startsWith("напиши ") -> {
                val text = raw.substringAfter("напиши ", "").trim()
                val ok = service?.typeIntoFocusedField(text) == true
                say(if (ok) "Ввожу текст" else "Сначала открой поле ввода и поставь в него курсор")
            }
            command.contains("прочитай экран") -> {
                val screen = service?.readVisibleText().orEmpty()
                say(if (screen.isBlank()) "На экране нет доступного текста" else screen.take(700))
            }
            else -> say("Пока не знаю эту команду. Попробуй сказать: домой, назад, прокрути вниз или открой YouTube.")
        }
    }

    private fun say(text: String) {
        status.text = text
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alina_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("ru", "RU")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
